__version__ = "0.2.1"
from openvino_vehicle_detection_adas.model import InferenceModel
