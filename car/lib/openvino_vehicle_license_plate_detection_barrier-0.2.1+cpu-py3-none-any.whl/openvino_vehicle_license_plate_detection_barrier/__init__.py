__version__ = "0.2.1"
from openvino_vehicle_license_plate_detection_barrier.model import InferenceModel
